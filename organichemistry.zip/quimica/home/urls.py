from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path("",views.home,name='home'),
    path("alquidral",views.alquidral,name='home'),
    path("derhal",views.derhal,name='derhal'),
    path("alcohol",views.alcohol,name='alcohol'),
    path("alqui",views.alqui,name='alqui'),
    path("alque",views.alque,name='alque'),
    path("alco",views.alco,name='alco'),
    path("ete",views.ete,name='ete'),
    path("et",views.et,name='et'),
    path("cetonas",views.cetonas,name='cetonas'),
    path("oxialq",views.oxialq,name='oxialq'),
    path("acido",views.acido,name='acido'),
    path("amida",views.amida,name='amida'),
    path("alca",views.alca,name='alca'),
    path("carbagua",views.carbagua,name='carbagua'),
    path("alcahalo",views.alcahalo,name='alcahalo'),
    path("bajt",views.bajt,name='bajt'),
    path("altt",views.altt,name='altt'),
    path("hidrat",views.hidrat,name='hidrat'),
    path("eter",views.ete,name='eters'),
    path("salbase",views.salbase,name='salbase'),
    path("alcohal",views.alcohal,name='alcohal'),

    path("oxidalco",views.oxidalco,name='oxidalco'),
    path("eteral",views.eteral,name='eteral'),
    path("hrefmap",views.hrefmap,name='hrefmap'),
    path("salmetal",views.salmetal,name='salmetal'),
    path("amidas",views.amidas,name='amidas'),
    path("derar",views.derar,name='derar'),
    path("ester",views.est,name='est'),
    path("derarhal",views.derarhal,name='home'),
    path("deraralc",views.deraralc,name='deraralc'),
    path("alcopoli",views.alcopoli,name='alcopoli'),
    path("poliamida",views.poliamida,name='poliamida'),
    path("poliester",views.poliamida,name='poliester'),
    
]
