from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request, "sonihome.html")
def alquidral(request):
    return render(request, "alquidral.html")
def derhal(request):
    return render(request, "derhal.html")
def alcohol(request):
    return render(request, "alcohol.html")
def alqui(request):
    return render(request, "alqui.html")
def alque(request):
    return render(request, "alque.html")
def alco(request):
    return render(request, "alco.html")
def ete(request):
    return render(request, "ete.html")
def et(request):
    return render(request, "et.html")
def oxialq(request):
    return render(request, "oxialq.html")
def cetonas(request):
    return render(request, "cetonas.html")
def acido(request):
    return render(request, "acido.html")
def amida(request):
    return render(request, "amida.html")
def alca(request):
    return render(request, "alca.html")
def carbagua(request):
    return render(request, "carbagua.html")
def alcahalo(request):
    return render(request, "alcahalo.html")
def bajt(request):
    return render(request, "bajt.html")
def altt(request):
    return render(request, "altt.html")
def hidrat(request):
    return render(request, "hidrat.html")
def salbase(request):
    return render(request, "salbase.html")
def alcohal(request):
    return render(request, "alcohal.html")
def oxidalco(request):
    return render(request, "oxidalco.html")
def eteral(request):
    return render(request, "eteral.html")
def hrefmap(request):
    return render(request, "hrefmap.html")
def salmetal(request):
    return render(request, "salmetal.html")

def amidas(request):
    return render(request, "amida.html")
def derar(request):
    return render(request, "derar.html")
def est(request):
    return render(request, "est.html")
def derarhal(request):
    return render(request, "derarhal.html")
def deraralc(request):
    return render(request, "deraralc.html")
def alcopoli(request):
    return render(request, "poli.html")
def poliamida(request):
    return render(request, "poliamida.html")
def poliester(request):
    return render(request, "poliester.html")

    
    
